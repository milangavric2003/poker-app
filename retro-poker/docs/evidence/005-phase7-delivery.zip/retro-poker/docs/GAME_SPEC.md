# GAME_SPEC — Retro Poker

Verzija: 1.2.2 · Datum: 2026-10-06 · Faza: Week03 + Week04 + odobreni Week05 scope addendum

Status: Week03 specifikacija sa Week04 i Week05 scope amandmanima. Week04 implementacija
je zabeležena u [evidence](EVIDENCE_003.md) i [feature 002 task listi](../specs/002-week04-ai-integration/tasks.md).
Week05 zahtev je razrađen u [feature 003](../specs/003-week05-bounded-agent-coach/spec.md);
njegova implementacija i provere nisu ovim amandmanom proglašene završenim.

## 1. Namera i potvrđene odluke

Retro Poker je lokalna browser igra No-Limit Texas Hold'em sa retro vizuelnim stilom. Jedan čovek igra protiv jednog do pet programskih botova za virtuelne žetone, za stolom sa najviše šest učesnika. Odvojeni backend vodi pravila i stanje partije u memoriji, a frontend prikazuje informacije dostupne čoveku i prima njegove poteze. Partija se nastavlja kroz više ruku, stackovi se prenose i igrači bez žetona ispadaju. Week03 isporuka pokazuje igru i proverljiv razvoj kroz Spec Kit, TDD, strukturisane ugovore, eval i evidence; AI analiza završene ruke pripada Week04.

Potvrđeno od vlasnika projekta:

- Predavač je prihvatio poker kao izbor igre.
- Koristi se Spec Kit; implementacija prati SDD i TDD.
- Pravi se mali backend radi podele posla, iako nije obavezan u izvornom zadatku.
- Varijanta je No-Limit, sa all-in i side potovima; raniji predlog fiksnih uloga je odbačen.
- Aplikacija se pokreće samo lokalno; nema pravog novca, naloga, ljudskog multiplayera, baze, leaderboarda ili deploymenta.
- Kontinuirana partija završava kada čovek ispadne ili ostane jedini igrač.

Projektni podrazumevani izbori za v1: pet botova, 1.000 žetona po učesniku, small/big blind 5/10 bez rasta i bez ante-a; jedan žeton je najmanja jedinica. To su parametri demo igre, ne univerzalni poker standard. Korisnik bira samo broj botova pri novoj partiji. Nema rebuy-a, dopune stacka ili menjanja parametara usred partije. Odobreni Week05 agentski tok radi posle završetka partije i ne menja parametre igre.

`6-max` znači najviše šest mesta, ne obavezno šest aktivnih igrača u svakoj ruci. Prilikom početka učesnici zauzimaju uzastopna mesta, čovek mesto 0; prazna mesta ne učestvuju. Prvi button je na čoveku. Odabrana mesta ostaju stabilna do kraja partije.

## 2. Cilj, kontrole i rezultat

Cilj igrača je da osvoji sve žetone protivnika. Pobeda u jednoj ruci može nastati osvajanjem pota bez showdown-a ili dobitkom jednog ili više potova na showdown-u. Dobitak ruke nije isto što i pobeda u partiji.

Kontrole su miš i tastatura kroz standardne fokusabilne UI elemente:

- Izbor 1–5 botova i `Nova partija`; podrazumevano pet.
- `Fold`, `Check`, `Call`, `Bet`, `Raise`, `All-in`, prema dozvoljenim akcijama.
- Numerički unos za bet/raise; UI jasno piše da li se unosi ukupan ulog u toj rundi i koliko se dodatno skida sa stacka. Naziv kontrole je `Bet/Raise to` odnosno `Ukupno u ovoj rundi`.
- `Sledeća ruka`, tek posle rezultata prethodne ruke i ako partija nije završena.
- `Nova partija` resetuje prethodnu, uz potvrdu samo ako je partija još u toku.

Nema vremenskog ograničenja za ljudski potez. Dok backend obrađuje akciju ili igra bot, ljudske kontrole ne mogu slati novi potez. Posle fold-a čoveka botovi završavaju ruku, a korisnik vidi poteze i rezultat. Posle eliminacije čoveka nema dodatne simulacije završetka partije između preostalih botova.

## 3. Osnovni game loop

```text
Konfiguracija → Nova partija → Button/blindovi → Deljenje
    → Pre-flop → Flop → Turn → River → Showdown
    → Obračun potova → Rezultat ruke → Provera eliminacije
    → Sledeća ruka ili Pobeda/Poraz
```

Ako ostane jedan igrač koji nije fold-ovao, ruka se završava odmah. Ako dalje ulaganje nije moguće, preostale zajedničke karte se podele automatski i sledi obračun. Svaka prihvaćena akcija i automatski prelaz imaju jednoznačan redosled u istoriji.

Backend ne sme da čeka potez igrača koji je fold-ovao, all-in ili eliminisan. Runda se završava tek kada su svi koji mogu da odlučuju odgovorili na poslednju relevantnu promenu uloga; jednakost iznosa sama nije dovoljna (npr. BB i dalje ima opciju posle limp-ova).

## 4. Osam ključnih pravila igre

| ID | Pravilo |
|---|---|
| R1 | Špil ima 52 jedinstvene karte, bez džokera; dva kruga deljenja daju po dve privatne karte učesniku. Nema dupliranja karata. |
| R2 | Zajedničke karte otkrivaju se 3–1–1. Pre svake grupe sagoreva se jedna karta, skrivena od UI-ja i botova. |
| R3 | Potezi idu u smeru kazaljke na satu; pre-flop počinje posle BB, kasnije posle button-a. Fold/all-in igrači se preskaču. |
| R4 | Check zahteva da nema doplate; call doplaćuje dug do granice stacka; fold odustaje od prava na pot. |
| R5 | Bet je najmanje BB, raise najmanje prethodni puni inkrement; maksimum je stack, bez ograničenja broja raise-ova. Kraći all-in je dozvoljen. |
| R6 | All-in igrač zadržava pravo na odgovarajuće potove; nepotvrđen višak uloga se vraća. Žetoni se ne stvaraju niti gube. |
| R7 | Na showdown-u se poredi najboljih pet od sedam karata, uz 0–2 privatne karte; jednake kombinacije dele pot, bez prednosti boje. |
| R8 | Stackovi se prenose; eliminacija se utvrđuje tek posle raspodele svih potova. Nova ruka koristi nov promešan špil. |

Osnovna pravila: [PokerStars — Texas Hold'em](https://www.pokerstars.com/poker/games/texas-holdem/). Sledeća preciziranja i acceptance primeri su obavezan deo specifikacije.

### 4.1. Button, blindovi i dva igrača

Koristi se dead-button pravilo pri eliminaciji: sledeći preživeli igrač posle prethodnog BB dobija BB; button/SB mogu biti na eliminisanom mestu radi pravilnog napredovanja blindova. Prazna mesta koja nikada nisu učestvovala ne stvaraju dodatne poteze ili blindove. Plan mora da priloži tabelu prelaza za eliminaciju button-a, SB, BB i više igrača odjednom.

Heads-up: button postavlja SB, igra prvi pre-flop i poslednji posle flop-a. Pri prelasku na dva igrača raspored se prilagođava da preživeli prethodni BB ne plaća BB uzastopno. Heads-up deljenje počinje od BB.

Ako stack ne pokriva blind, ulaže se preostali iznos i igrač je all-in; nominalni BB ostaje minimum pre-flop otvaranja. Postavljeni blind ulazi u lični doprinos te runde i cele ruke.

### 4.2. Raise i ponovno pravo na raise

Kraći all-in ne menja poslednji puni raise inkrement. Za igrača koji je već reagovao, ponovno pravo zavisi od ukupnog povećanja s kojim se sada suočava; više kratkih all-in povećanja može zajedno dostići puni raise. Evidentiraj pravo po igraču, ne jednim globalnim boolean-om. Nepuna početna all-in opklada ispod BB ne postaje novi puni minimum; acceptance testovi moraju obuhvatiti check pre takvog otvaranja.

Primer: BB je 10; na flop-u A check, B all-in 4, C još nije igrao i ima dovoljno žetona. C može fold, call 4 ili raise na najmanje 14; dopuna na 10 nije legalan običan raise. Ako C call-uje 4, A može fold/call, ali nema pravo na raise. Ako C raisuje na 14, A ponovo ima pravo na raise, najmanje na 24. Videti TDA objašnjenja [minimalnog raise-a posle kratkog otvaranja](https://www.pokertda.com/forum/index.php?topic=279.0) i [prava igrača koji je prethodno check-ovao](https://www.pokertda.com/forum/index.php?topic=746.0).

### 4.3. Potovi i završetak

Svaki pot računa se i deli zasebno. Pravo imaju samo nefoldovani učesnici odgovarajućeg nivoa doprinosa. Preostali nedeljivi žetoni dodeljuju se dobitnicima redom od prvog mesta levo od button-a.

Referenca za ova preciziranja: [Poker TDA, pravila 21, 23, 34–36 i 49](https://www.pokertda.com/view-poker-tda-rules/). Koristimo pravila relevantna za digitalnu igru; fizičke greške deljenja, usmene deklaracije i turnirske kazne nisu deo aplikacije.

Jedini preostali igrač sa žetonima ne može da ulaže protiv već all-in protivnika u pot bez protivnika: prvo dobija priliku da call/fold-uje eventualni dug, zatim sledi automatsko otkrivanje ostatka board-a. Ako najmanje dva nefoldovana igrača imaju žetone, mogu da nastave ulaganje za side pot.

Pri kraju ruke backend tačno jednom vraća nepotvrđen višak i tačno jednom isplaćuje svaki pot. Foldovani doprinosi ostaju u obračunu. `HandResult` prikazuje dobitnike po potu, isplate, vraćene iznose i neto promenu stacka; ne svodi side-pot rezultat na jednog globalnog pobednika.

### 4.4. Evaluator i otkrivanje karata

Poređenje obuhvata sve kategorije, kickere i izbor pet karata; A može biti najniža karta u A–2–3–4–5, ali nema wrap-around straight-a. Royal flush je najviši straight flush. Kada najbolju kombinaciju čini board, privatne karte ne menjaju nerešen ishod.

Za v1 svi učesnici showdown-a automatski otkrivaju karte; nema opcije muck. Foldovane karte ostaju skrivene. Pri pobedi fold-om svih protivnika nema automatskog otkrivanja protivničkih karata. Nepodeljeni špil, burn karte i RNG seed nikada se ne šalju klijentu.

## 5. Botovi

- BOT1: Jedna jednostavna dokumentovana strategija, bez izbora težine, LLM-a, solvera i spoljnog API-ja.
- BOT2: Bot prima sopstvene karte, javno stanje, javnu istoriju i legalne akcije. Nema pristup tuđim skrivenim kartama, redosledu špila ili budućem board-u.
- BOT3: Svaki potez prolazi isti domenski validator. Engine ne prihvata nelegalan potez ni od bota.
- BOT4: U testovima odluke i slučajnost mogu da se zamene determinističkim fixture-om. RNG bota je odvojen od mešanja špila.
- BOT5: Greška strategije ne blokira partiju: zabeleži dijagnostiku i odaberi legalan check, a ako check nije legalan, fold. Testovi moraju otkriti da je fallback korišćen.
- BOT6: UI redom prikazuje događaje botova. Eventualna animacija ne određuje pravila niti zahteva realno čekanje u engine testovima.

## 6. Arhitektura i lokalno pokretanje

| ID | Zahtev |
|---|---|
| ARCH1 | TypeScript frontend i backend, engine nezavisan od transporta i prikaza; konkretni framework-i se biraju u `plan.md`. |
| ARCH2 | Mali HTTP API za novu partiju, javno stanje, ljudsku akciju i sledeću ruku. Backend sam izvršava bot poteze; klijent ne šalje poteze u ime bota. |
| ARCH3 | Jedna aktivna lokalna partija u memoriji, bez trajnog snimanja. Nova partija zamenjuje staru. |
| ARCH4 | Oba servisa slušaju loopback, nikada podrazumevano `0.0.0.0`. Ako su različiti origin-i, dozvoli samo dokumentovani lokalni frontend origin. |
| ARCH5 | Posle instalacije zavisnosti igra i testovi rade bez interneta, AI ključeva, CDN fontova ili udaljenih asseta. |
| ARCH6 | Refresh UI-ja učitava aktuelno backend stanje. Restart backend-a gubi partiju i prikazuje ekran nove partije; ne simulirati uspešan nastavak. |
| ARCH7 | Obrada akcija je serijska i proverava `gameId`, `handId` i očekivanu reviziju. Dupli klik ili zastareo zahtev ne primenjuje potez dva puta. |
| ARCH8 | Greška mreže ostavlja poslednji potvrđeni prikaz i nudi ponovno učitavanje stanja. Ne ponavljaj automatski zahtev koji menja igru. |

Test fixture-i smeju da postave špil i stackove kroz test interfejs u procesu. Produkcioni HTTP API ne nudi debug/reset-stack/set-deck endpoint. Dijagnostika i development evidence nisu trajno čuvanje partija za igrača.

## 7. Strukturisani ugovori i runtime validacija

Ovo su zahtevi za ugovore; detaljne šeme i HTTP rute nastaju u Spec Kit planu pre implementacije oba dela. Jedan deljeni modul sadrži šeme i tipove.

| Ugovor | Obavezna semantika |
|---|---|
| `GameConfig` | Jedino polje `botCount`: obavezan ceo JSON broj od 1 do 5; nepoznata polja se odbijaju. Fiksni stack i blindovi su serverske konstante. |
| `PlayerAction` | Identifikatori partije/ruke, očekivana revizija, diskriminisana akcija. `bet`/`raise` zahtevaju `amountTo`, ostale akcije ga ne prihvataju. |
| `GameView` | Javna mesta, stackovi, doprinosi, statusi, button/blindovi, faza, otkrivene karte, čovekove karte, igrač na potezu, potovi, revizija, legalne akcije i rasponi. |
| `HandResult` | Identitet završene ruke, razlog završetka, potovi sa eligible/winner ID-jevima, isplate/refund-i, otkrivene karte, neto promene i status partije. |
| `GameError` | Stabilan kod i razumljiva poruka bez privatnog internog stanja; razlikuje invalidan format, nelegalan potez, zastarelo stanje i nepostojeću partiju. |

`amountTo` je ukupan doprinos igrača u tekućoj betting rundi nakon akcije, ne iznos doplate. Doplata je `amountTo - streetContribution`; maksimalno `streetContribution + stack`. `call` sam računa `min(toCall, stack)`, a `all_in` ulaže ceo preostali stack samo kada njegova klasifikacija kao call/bet/raise poštuje trenutna prava igrača. All-in dugme ne zaobilazi zabranu raise-a.

Validan primer konfiguracije:

```json
{ "botCount": 5 }
```

Nevalidni primeri: `{}`, `{"botCount":0}`, `{"botCount":6}`, `{"botCount":2.5}`, `{"botCount":"3"}`, `{"botCount":3,"startingStack":999999}`. Svi moraju biti odbijeni pre kreiranja ili zamene partije; postojeća partija ostaje netaknuta.

Za akcije odbij negativne iznose, razlomke, nepoznatu akciju, višak polja, pogrešnu fazu ili identifikator, potez van reda i zastarelu reviziju. Frontend koristi runtime proveru odgovora pre prikaza; backend proverava i oblik i domenska pravila pre promene stanja. Čak i validan JSON može biti semantički nelegalan.

## 8. Vizuelni minimum

- Originalan retro izgled: jednostavan zeleni sto, piksel/monospace stil, čitljive karte i žetoni, najviše šest jasno označenih mesta. Bez kopiranja brendova ili tuđih asseta.
- Čovek je vizuelno izdvojen; rang i znak karte čitljivi su bez oslanjanja isključivo na boju.
- Prikazuju se faza, button/SB/BB, aktivni igrač, stackovi, ulozi, ukupan pot i side potovi kada postoje, uz kratku istoriju događaja.
- Nedozvoljene akcije su onemogućene ili skrivene; prikazuju se call iznos i bet/raise granice iz `GameView`.
- Ekran rezultata ostaje vidljiv do `Sledeća ruka`. Prikazuje raspodelu i promenu žetona, bez strateških ili navodno AI zaključaka.
- Minimalni demo viewport: desktop 1280×720, bez preklapanja kontrola i horizontalnog skrolovanja. Fokus, label-e i poruke o greškama moraju biti čitljivi. Mobilni raspored, zvuk i složene animacije nisu DoD.
- Tekst interfejsa je srpski latinicom; standardne poker akcije mogu zadržati engleske nazive. Nema internog debug JSON-a ili Spec Kit detalja u korisničkom toku.

## 9. Acceptance scenariji i test oracle

Očekivanja se zapisuju pre implementacije. Primeri sa različitim stackovima su test snapshot-i kasnijeg toka partije, ne nove korisničke postavke.

| ID | Given / When | Then |
|---|---|---|
| AC01 | Nova partija, pet botova | Šest učesnika; početno ukupno 6.000 žetona; posle blindova zbir stackova i pota ostaje 6.000; svako ima dve jedinstvene karte. |
| AC02 | Početak sa jednim botom | Heads-up button/SB igra prvi pre-flop; BB igra prvi post-flop. |
| AC03 | Pozitivni testovi za svaki `botCount` 1–5; nevalidni primeri iz §7 | Validni počinju sa tačnim brojem učesnika; nevalidni vraćaju grešku bez mutacije postojeće partije. |
| AC04 | Igrač duguje 20, pošalje check | Odbijanje; stack, pot, red poteza, revizija, špil i istorija prihvaćenih akcija nepromenjeni. |
| AC05 | Trenutni ulog 30, poslednji puni raise inkrement 20; igrač ima dovoljno žetona i pravo da raisuje | Raise to 49 se odbija; raise to 50 se prihvata. |
| AC06 | Igrač ima doprinos 10, stack 90; raise to 60 je legalan | Skida se 50; ostaje stack 40, doprinos postaje 60. |
| AC07 | Dug 100, preostali stack 40, call | Ulaže 40, postaje all-in; nema negativnog stacka ni eliminacije pre obračuna. |
| AC08 | A bet 100; B all-in to 140; akcija se vrati A | A nema novo pravo na raise samo zbog povećanja od 40. |
| AC09 | A bet 100, B all-in 140, C call 140, D all-in 200 | A ponovo može da raisuje; ako A call-uje 200, C nema ponovno pravo na raise zbog doplate od 60. |
| AC10 | BB 10; na flop-u A check, B all-in 4, C još nije igrao; A/C imaju dovoljno žetona | C call 4 je legalan, običan raise to 10 nije, raise to 14 jeste. Posle C call-a A nema pravo na raise; posle C raise-a na 14 A može raise na najmanje 24. |
| AC11 | Završni doprinosi A=100, B=250, C=250; niko nije fold; A ima najbolju, B drugu kombinaciju | Glavni pot 300 dobija A, side pot 300 dobija B; C dobija 0. |
| AC12 | A ulaže 200, B all-in call ukupno 80; nema drugih doprinosa | A dobija refund 120; osporeni pot je 160 i deli se prema kartama. |
| AC13 | Pot 15: A i B imaju istu najbolju kombinaciju, C je foldovao posle svog doprinosa 5 | A/B dobijaju 8/7 po redosledu mesta levo od button-a; C ne dobija ništa. |
| AC14 | Board A♠ K♠ Q♠ J♠ 10♠, najmanje dva učesnika showdown-a | Dele pripadajući pot; privatne karte ne određuju pobednika. |
| AC15 | A–2–3–4–5 naspram 2–3–4–5–6; odvojeni primeri kickera, dve trojke i tri para | Šest-visoki straight je jači; evaluator bira ispravnih pet i kickere; dodatni fixture-i unapred navode konkretne karte i ishod. |
| AC16 | Svi osim jednog fold-uju | Tačno jedna isplata i rezultat bez nepotrebnog deljenja board-a ili otkrivanja foldovanih karata. |
| AC17 | Čovek fold, botovi ostanu u ruci | Botovi je završavaju; UI ne čeka potez čoveka; dostupan je rezultat. |
| AC18 | Dva identična zahteva sa istom očekivanom revizijom | Najviše jedna prihvaćena akcija; drugi zahtev se odbija kao zastareo i nudi se novo stanje. |
| AC19 | Backend snapshot sadrži sve privatne karte i špil | HTTP odgovor pre showdown-a nema tuđe karte, seed, burn karte ni redosled špila; bot input nema skrivene podatke protivnika. |
| AC20 | Posle raspodele čovek ima 0 / svi botovi imaju 0 | Prikaz poraza / pobede; nova ruka nije moguća; nova partija ponovo daje početne stackove. |
| AC21 | Eliminacija sa šest na manje igrača i sa tri na dva | Blindovi/button i red poteza slede §4.1; mrtva mesta ne blokiraju tok. |
| AC22 | Refresh UI-ja / restart backend-a | Učitava se postojeća partija / prikazuje kontrolisano odsustvo partije i nova igra. |
| AC23 | Puna ruka kroz UI sa kontrolisanim špilom i botovima | Ispravne faze, dozvoljene kontrole, tačan rezultat i nastavak sledeće ruke sa prenetim stackovima. |

AC15 i AC21 zahtevaju konkretne fixture tabele u planu pre RED testova, a ne samo test imena. Svaki fixture navodi početno stanje, poteze i unapred izračunat ishod.

Invarijante za svaki prihvaćeni prelaz: nema duplikata karata; nema negativnih/razlomljenih žetona; zbir stackova i još neisplaćenih doprinosa je konstantan; nema poteza van reda; refund i payout ne mogu se izvršiti dvaput. Doprinosi prikazani u UI-ju ne broje se drugi put ako su već uključeni u pot.

## 10. Week03 razvoj i dokazi

Sve naredne stavke su planirane isporuke, ne tvrdnja da već postoje:

| Artefakt | Potreban sadržaj |
|---|---|
| `AGENTS.md` | Kratke trajne instrukcije, scope i način provere. |
| `.specify/memory/constitution.md` | Popunjeni principi, obavezan TDD, mali scope i dokaz; bez placeholder-a. |
| `specs/<feature>/spec.md`, `plan.md`, `tasks.md` | Scenariji sa vezom na ID-jeve, tehnički plan, ugovori i mali zadaci oba člana. |
| `docs/BUILD_PROMPT_V1.md` | Sačuvan pre prve velike implementacije; uloga, cilj, kontekst, pravila, dozvoljene izmene, DoD i provere, plan i nejasnoće. |
| `docs/CONTEXT_MANIFEST.md` | Stvarno uključeni/izostavljeni izvori, verzije, prioritet, razlog i rizik za značajne pozive. |
| `docs/EVALS.md` | Očekivanja pre pokretanja; ista tabela baseline/posle, komande, fixture-i i statusi. |
| `docs/EVIDENCE_003.md` | Baseline referenca, problem, hipoteza, jedna promena, isti eval, stvarni logovi/screenshoti, ograničenje i doprinos oba člana. |
| `docs/AI_USAGE_LOG.md` | Značajni pozivi, svrha, očekivanje, kontekst, rezultat, odluka i dostupna potrošnja; nepoznate vrednosti jasno označene. |
| `README.md` | Instalacija, tačne verzije, lokalne komande/adrese, testovi, reset i poznata ograničenja. |

Minimalni eval: E1 puna tipična ruka; E2 granični broj botova (1 i 5); E3 nevalidan `GameConfig`; E4 stvarni propust prve verzije. E4 se bira tek iz zabeleženog baseline nalaza. Ne izmišljati grešku, ne izazivati je namerno i ne prepravljati rezultate. Ako propust nije pronađen, zabeležiti ograničenje i proširiti stvarne provere; ne tvrditi da je taj kriterijum završen.

Za kontrolisanu promenu zapiši: tvrdnju, signal, hipotezu, najmanju promenu, nepromenjene uslove, komandu, rezultat i ograničenje. Sačuvaj baseline pre popravke i ponovi isti skup posle nje; ne menjaj istovremeno prompt, kontekst, šemu i kriterijume. Dodaj holdout koji nije korišćen za doradu.

Za svaki implementacioni task čuvaj smislen RED, najmanji GREEN i relevantnu regresiju. Oba člana treba da mogu da ponove tuđi dokaz i objasne svoju promenu. Zajednički ugovori prethode nezavisnom radu, uz redovnu zamenu driver/reviewer uloga i jedan aktivni coding agent. U Week05 članovi rade naizmenično kada imaju raspoložive tokene; svako može nastaviti otvoreni task uz handoff belešku. Nema istovremenog menjanja istih fajlova.

## 11. Definition of Done za Week03

- [ ] Popunjeni su Spec Kit constitution, feature specifikacija, plan i taskovi; AC15/AC21 imaju konkretne fixture tabele i očekivanja pre implementacije.
- [ ] Početni prompt i context manifest sačuvani su pre velike implementacije.
- [ ] Frontend i backend se pokreću lokalno po README-u; igra radi bez spoljne mreže nakon setup-a.
- [ ] Konfiguracije sa 1–5 botova su podržane; pet je podrazumevano.
- [ ] Kontinuirana No-Limit partija obuhvata all-in, legalne raise-ove, side potove, tie/refund, ispadanje i heads-up.
- [ ] AC01–AC23 imaju konkretne prolazne testove ili jasno navedenu ručnu proveru za vizuelne zahteve; nijedna nepokrivena obavezna stavka se ne prećutkuje.
- [ ] Prikaz i botovi poštuju ograničenja vidljivosti; backend odbija nelegalne i zastarele akcije bez mutacije.
- [ ] Prikazani su validan i nevalidan strukturisan primer, runtime odbijanje i semantička provera.
- [ ] Postoje stvarni RED/GREEN dokazi; fokusirani i regresioni testovi, E2E, typecheck, lint i build prolaze.
- [ ] Baseline je ponovljiv i očuvan; postoji stvaran propust, hipoteza i jedna kontrolisana promena proverena istim eval skupom, plus nezavisan holdout.
- [ ] `EVIDENCE_003.md` i `AI_USAGE_LOG.md` sadrže stvarne rezultate, potrošnju kada je dostupna, ograničenja i doprinos oba člana.
- [ ] Drugi član može iz checkout-a da instalira, pokrene igru i ponovi dokumentovane provere.

Za Week03 demo prikažite jednu ruku, spec/prompt/manifest, isti baseline scenario pre i posle promene, runtime odbijanje i evidence. Obojica objašnjavaju svoj doprinos. Week04 tool-calling deo zajedničkog demo plana još nije uslov.

## 12. Van scope-a i odobreni Week04 scope

Van Week03: pravi novac i plaćanja; nalozi i autentifikacioni sistem; drugi ljudski igrači ili udaljeni server; baza i trajni save/replay; leaderboard; deployment; rast blindova/turnirski nivoi i više stolova; rebuy; više varijanti pokera; izbor težine; napredni solveri; mobilna optimizacija; zvuk; spoljne slike/fontovi; autonomni agenti u igri.

AI rezime, procena poteza, tool calling i provider SDK ne implementiraju se u Week03.
Week03 beleži uređenu istoriju u memoriji za aktuelnu i poslednju završenu ruku,
uključujući informacije dostupne čoveku u trenutku poteza, akciju, iznose i konačne
činjenice. Stariji rezultati ne zahtevaju trajnu arhivu. Istorija se gubi restartom
backend-a.

Odobreni Week04 scope, razrađen u feature-u
[`002-week04-ai-integration`](../specs/002-week04-ai-integration/spec.md), proširuje
prethodnu read-only granicu sledećim kontrolisanim sposobnostima:

- igrač može uključiti AI režim za postojeću konfiguraciju od 1–5 botova; Gemini model
  predlaže strukturisan potez, ali backend proverava privatnost, reviziju i legalnost
  kroz postojeći poker engine pre bilo kakve standardne mutacije;
- bot dobija samo javno stanje i sopstvene privatne karte dozvoljene u trenutku poteza;
  tuđe skrivene karte, buduće karte, seed i interni špil ostaju nedostupni;
- po završetku partije model može generisati strukturisan obrazovni rezime ljudskih
  poteza, dobrih odluka, mogućih grešaka i sledećih saveta. Analiza razlikuje znanje
  dostupno u trenutku odluke od kasnijeg ishoda; pobeda ili poraz sami ne dokazuju
  kvalitet poteza;
- Gemini API je prvi provider; timeout, rate limit, ograničeni retry/model fallback,
  deterministički lokalni bot fallback, očuvanje game state-a i fake/mock test putanja
  obavezni su delovi Week04 ugovora;
- lokalni, in-memory AI usage dashboard prikazuje agregate poziva i pokušaja, greške,
  fallback, latenciju i usage/trošak samo kada ih provider stvarno vrati. Ne čuva
  prompt, privatne karte, API ključ ni raw provider odgovor.

Model ni u ovom proširenom scope-u nije autoritet nad pravilima i ne izvršava akciju
samostalno. Svaki modelski predlog je nepoverljiv input koji backend validira; samo
potvrđeni legalni predlog može proći isti autoritativni put kao lokalni bot. Week04
ostaje lokalni scope bez naloga, ljudskog multiplayera, baze, trajnog replay-a,
leaderboarda, deploymenta ili drugog provider family-ja. Tačni model ID-jevi, SDK,
endpoint-i i operativni pragovi pripadaju feature planu.

## 13. Odobreni Week05 scope — bounded agent za analizu

Week05 nastavlja postojeću završnu analizu i uvodi ograničen agentski tok za obrazovni
pregled **jedne završene partije**. Korisnik zadaje cilj analize. Model predlaže sledeći
dozvoljeni korak, backend proverava predlog, izvršava jedan allowlist-ovan lokalni
read-only alat, proverava rezultat i vraća ga modelu za strukturisani konačni odgovor.

- Core alat `get_decision_evidence` bira ograničen skup odluka iz već raspoloživih
  `MatchFacts`, prema dozvoljenom fokusu i malom limitu. Backend veže alat za snapshot
  završene partije; klijent/model ne može proslediti proizvoljan `GameState` ili
  identifikator kojim bi čitao drugu partiju.
- Uspešan agentski run sadrži najmanje dva odvojena modelska koraka i makar jedno
  stvarno izvršenje alata između njih. Week04 retry/fallback attempt nije dodatni
  modelski korak. Postojeća analiza ostaje prepoznatljiv Week04 put dok nova funkcija
  ne prođe svoje acceptance provere.
- Predlog, argumenti, dozvola, budžet, scope partije, rezultat alata i konačni odgovor
  validiraju se serverski. Evidence reference moraju pripadati snapshot-u, a tvrdnja
  `completed` ne sme se prihvatiti uz nevažeće ili nedovoljne dokaze.
- Potvrđeni budžet T005 (2026-10-04): najviše 2 modelska koraka, 1 izvršenje alata,
  4 provider pokušaja ukupno, 45 sekundi za run i 15 sekundi po provider pokušaju,
  pri čemu svaki pokušaj koristi samo preostali ukupni rok. Retry nije novi korak;
  najviše dva pokušaja po koraku, tool limit 1–10 i rezultat najviše 20480 UTF-8
  bajtova. Lokalni tool rok je do 1 s u okviru ukupnog roka. Konačne semantike,
  retention i stop taxonomy su u feature 003 plan/data-model ugovoru; runtime
  testovi tek slede, potvrda dokumentacije nije dokaz izvršenja.
- Ponavljanje istog alata i normalizovanih argumenata u istoj facts reviziji zaustavlja
  run pre drugog izvršenja. Nepoznat alat, loši argumenti i prekoračenje budžeta ne
  izvršavaju alat. Greške provajdera, alata ili finalne validacije završavaju kontrolisano.
- Run je vezan za identitet i reviziju partije. Reset/nova partija ili zastareli
  snapshot sprečavaju da kasan agentski rezultat bude prikazan kao važeći.
- UI prikazuje korisnički cilj, status, strukturisanu preporuku, raspoložive dokaze i
  bezbedan stop razlog; ne prikazuje sirove promptove, chain-of-thought, tajne ili
  interne stack trace-ove.
- Core agent je read-only. Nema promene poker state-a, pokretanja sledeće ruke,
  alata za upis, proizvoljnih URL-ova, shell-a, filesystem-a ili SQL-a. Nema trajne
  istorije ni novih servisa/baze; koristi se postojeći provider i memorijski podaci.
- Partija može imati do 200 detaljnih ljudskih odluka pre agregacije. UI/odgovor mora
  navesti da analiza koristi dostupni uzorak, a ne obećavati pregled arhive ili svih
  ranijih partija. Kvalitet odluke ne izvodi se iz samog kasnijeg ishoda.

Granica između faza je jasna: Week03 isporučuje igru, Week04 pojedinačne AI bot/analiza
interakcije i provider pouzdanost, Week05 kontrolisani višekoračni tok nad analizom.
Feature 003 ne menja poker pravila niti ranije acceptance oracle-e.

## 14. Week05 Definition of Done

Status proverljivih stavki osvežen 2026-10-05 prema
[Week05 evidence-u](EVIDENCE_W05.md) i [T025 mapi](evidence/003-T025-review.txt).
Ljudski gate ispod ostaje otvoren; tehnički checkbox nije potvrda obe osobe.

- [x] Feature 003 ima usaglašene spec, plan, taskove i sačuvan početni implementacioni
  prompt; ova specifikacija čuva obavezne proizvodne granice.
- [x] Cilj korisnika, jedan alat i njegove strict ulazne/izlazne šeme su dokumentovani.
- [x] Uspešan run ima najmanje dva modelska koraka i jedno validirano izvršenje alata.
- [x] Stroga runtime validacija pokriva preflight, model predlog, rezultate alata,
  evidence i finalni odgovor.
- [x] Run ima eksplicitno stanje, limite koraka/alata/poziva, pojedinačni timeout,
  ukupan rok, zaštitu od otkazivanja/zastarevanja i ponovljene akcije.
- [x] Read-only invariant dokazuje da poker stanje i činjenice nisu promenjeni agentom.
- [x] Fake testovi pokrivaju uspeh, nevalidan ulaz, nepoznat alat, loše argumente,
  grešku alata/provajdera, neispravan izlaz, ponavljanje, rok/limit koraka i lažne
  evidence reference; nedozvoljen predlog daje nula tool izvršenja.
- [x] UI prikazuje bezbedne statuse, rezultat i dokaze; postoje E2E/ručni zapisi.
- UI status se prikazuje jednom; safe failureCategory razjašnjava odbijanje forme
  ili nepoklapanje evidence-a. Opis coaching cilja prati postojeće filtere alata.
- [x] Evidence i AI usage log razlikuju logičko pokretanje, modelske korake, provider
  pokušaje i pozive alata; nema tajni ni chain-of-thought-a.
- [x] Obe osobe u paru mogu da objasne tok, allowlist, validaciju i stop uslove; njihov
  stvarni naizmenični doprinos dokumentovan je bez izmišljene potvrde.
  Korisnička potvrda2026-10-06 i [Git doprinos/handoff](evidence/003-T027-contributions.md).
- [x] Sve relevantne aplikacione provere su izvršene i zapisane sa stvarnim rezultatima;
  redovni testovi ostaju offline fake matrix.
- [x] Uspešan ograničen Week05 live demo kroz postojeći provider, dva model koraka,
  stvarni alat i validirani final ima zabeležen ishod. Assignment §31 traži limited
  live demo; Week04 live smoke i
  fake run ga ne zamenjuju. Neuspeh se beleži kao neuspeh, bez tvrdnje da je live
  success potvrđen. T030 odobrenje važilo je za jedan run. Za nastavak T031 korisnik
  odobrava više malih run-ova uz izričito pitanje i redni broj pre svakog novog run-a;
  dispatch čeka odgovor. Smernice ≤15 razvojnih/≤3 demo run-a nisu cilj potrošnje.

T030 runner/testovi i stvarni ishod su zabeleženi u
[handoff-u](evidence/003-T030-handoff.md): 1 live run, 2 model koraka/2 provider
poziva/1 alat, stopped/insufficient_evidence. T031 odobreni #2 sada zatvara live gate;
ljudski T027 tada je bio odložen, a zatvoren je korisničkom potvrdom2026-10-06.
Ne menjaju se poker pravila.

T031 offline priprema dodaje scenario sa četiri odluke i bezbednu projekciju vrste
modelskih koraka; ista ograničenja 2/2/1 i final validator ostaju. Odobreni live #2
ima completed, 4 evidence reference i read-only=true, retry/fallback0.
[Stvarni dokaz](evidence/003-T031-live-02.txt), [aktuelni handoff](evidence/003-T031-handoff.md).

## 15. Izvori i upravljanje promenama

### Privatni nastavak posle završenog Week05

Korisnički zahtev 2026-10-14 odobrava zaseban frontend feature
[`004-frontend-table-polish`](../specs/004-frontend-table-polish/spec.md), uključujući
mobilni raspored koji je bio van istorijskog Week03 scope-a. Karte, čipovi, sto i
paneli koriste postojeći javni pogled; poker pravila, API ugovori i AI granice se
ne menjaju. Week05 taskovi i dokazi ostaju istorijski zatvoreni. Novi dokazi su
u feature 004, provere offline/fake, bez stvarnih Gemini poziva.

- Retro AI Engineering Challenge — istorijski izvor za Week03 artefakte, eval i
  Week04 granicu: `../../week-03-week-04-pdf-review/materijali-za-studente/week-03-week-04-retro-ai-engineering-challenge.md`.
- Week03 studentska skripta — kontekst, strukturisani izlazi i TDD/SDD:
  `../../week-03-week-04-pdf-review/materijali-za-studente/week-03-studentska-skripta.pdf`.
- TDD/SDD addendum — test-first i razrada u male taskove:
  `../../week-03-week-04-pdf-review/materijali-za-studente/week-03-tdd-sdd-agentic-engineering-addendum.md`.
- Week04 AI API addendum — provider granica, structured output, timeout, retry i
  fake-first testovi: `../../week-03-week-04-pdf-review/materijali-za-studente/week-04-ai-api-integration-addendum.md`.
- Istorijski Week05 assignment ranije je bio u root `weekly-assignment.md`, koji
  je sada zamenjen Week08 zadatkom. W05 zahteve čuvaju feature 003 i njegov evidence;
  [Week05 reliability addendum](../../week-05-bounded-agentic-workflows-reliable-integration-addendum.md)
  ostaje lokalni izvor za bounded flow, tools, budžete i fake-first provere.
- [Week05 feature 003](../specs/003-week05-bounded-agent-coach/spec.md): implementacioni ugovor i acceptance scenarios.
- Poker izvori su linkovani uz pravila; provereni 2026-09-21. Nisu zamena za sopstvene determinističke testove.

Lokalni nastavni materijali nisu nužno deo Git checkout-a; ovaj dokument i projektni artefakti moraju omogućiti kolegi rad bez njih. Stariji `suggestion.md` ostaje istorijski predlog, a ovaj dokument beleži aktuelni dogovor. Promena ponašanja zahteva usklađivanje verzije ovog dokumenta, Spec Kit artefakata, acceptance scenarija i testova pre prihvatanja implementacije.

T030 audit potvrđuje da četiri navedena istorijska Week03/Week04 materijala nedostaju
u ovom checkout-u; putanje su sačuvane kao poreklo, bez nevažećih klikabilnih linkova.
Usvojeni zahtevi ostaju u ovom GAME_SPEC-u i verzionisanim feature001/002 artefaktima.
## Coaching transport — T033, 2026-10-06

Gemini bira dokaze iz validiranog read-only alata preko numerisanih činjenica;
backend prenosi originalne reference i finding tekst u postojeći final ugovor.
Strict provera i tačno članstvo dokaza ostaju obavezni. Model ne može proizvoljno
prepisati finding u ovom transportu; nepoznati/dupli izbori i nevalidna completion
se odbijaju. Budžeti, terminalni statusi, UI/API i poker pravila ostaju isti.
## T034/T035 — precizna dijagnostika i odobrena live provera

Opcioni outputIssue je safe enum za invalid_structured_response, bez model teksta.
Korisnik2026-10-06odobrio samostalne popravke i do50pojedinačnih Gemini zahteva,
isključivo gemini-3.5-flash-lite. To zamenjuje stariju obavezu pojedinačnog pitanja
pre svakog live run-a u okviru ovog rada. Lokalni gate je serijski,≥6000ms između
dispatch-a, hard cap50 kroz isti ledger; kvota korisnika RPM15, SDK retries/fallback
isključeni. Sintetički eval ne dodaje produkciono debug API, ne menja igru, ne slabi
tool/final validaciju i ne dokazuje stratešku optimalnost ili odsustvo svih grešaka.

Gemini šema u oba coaching koraka izražava string/number literale singleton enum-om;
neutralni ugovor i runtime provere ostaju nepromenjeni. Nevalidan kind se odbija,
uz safe outputIssue dijagnozu. Primenjeni T034/T035:48zahteva/24run-a, poslednja
matrica3cilja×3scenarija9/9completed; read-only24/24. Ovo je ograničen dokaz,
ne garancija budućih generacija. [Rezultati](evidence/003-T035-handoff.md).

## 16. Week08 — Secure the Arcade (završna provera 2026-10-26)

Korisnik odobrava bezbednosno ojačavanje postojećeg W05 coaching toka kroz
[feature 005](../specs/005-week08-secure-the-arcade/spec.md). Nova grana
`week08-init` polazi sa `add-modifications` i čuva privatne dorade frontenda,
ponavljanja summary-ja i AI analitike. One nisu Week08 doprinos. Week05 ostaje
zatvoren; otvoreni privatni PR se ne spaja u main ovom pripremom.

| ID | Proizvodna granica / prihvatanje |
|---|---|
| W08-01 | Normalna igra i coaching ostaju funkcionalni: ≥2 model koraka, ≥1 stvarni dozvoljeni alat i nepromenjen kanonski poker rezultat. |
| W08-02 | Nevalidan početni HTTP zahtev ne pokreće provider/tool; strict ulaz i serversko stanje sprečavaju klijentsko podmetanje identiteta, konfiguracije i rezultata. |
| W08-03 | Model predlaže samo dozvoljen alat; naziv/args/scope/output/final proverava server. Nema proizvoljnog čitanja, URL fetch-a, shell-a ili promene partije. |
| W08-04 | Per-run i procesne cross-request granice obuhvataju pokušaje, vreme, veličine i stvarno aktivan rad; retry/fallback/reset/timeout ih ne zaobilaze. |
| W08-05 | AI sadržaj ostaje neizvršiv tekst; produkcioni lokalni build ima proverena aktivna CSP/nosniff/referrer zaglavlja uz funkcionalan novi frontend. |
| W08-06 | Tajne nisu deo browser/model/log izlaza; minimalni bezbednosni događaji imaju dozvoljena polja i ograničen životni vek. |
| W08-07 | Očuvan local-only single-user model bez auth-a/baze; dokumentovati origin/credential granicu, audit zavisnosti i stvarna ograničenja. |
| W08-08 | T00–T17 dokazi, ≥3 ista pre/posle scenarija, ponovljiva fake-first provera i potvrđen doprinos oba člana; bez live ključeva/privatnih podataka. |

Tačne granice, HTTP kodovi i promene korisničkog retry ponašanja su u
[planu](../specs/005-week08-secure-the-arcade/plan.md) i
[ugovoru](../specs/005-week08-secure-the-arcade/contracts/security.md).
Nema naloga, privatnih multi-user resursa, novog game moda ili deployment-a.
Abort nije garancija prekida udaljene obrade/naplate. Fake test nije dokaz
otpornosti pravog modela niti produkcijske dostupnosti.

Week08 Definition of Done — lokalni tehnički dokaz i ljudska potvrda su odvojeni:

- [x] I1–I8 imaju izvršne kontrole i povezane prolazne testove.
- [x] T00–T15 i T17 automatizovani, T04/T05 u browseru, T16 stvaran production build.
- [x] Najmanje tri scenarija imaju isti input i pre/posle rezultate; PASS→PASS dozvoljen.
- [x] Sentinel, log injection, origin/CSRF primenljivost i dependency odluke dokumentovani.
- [x] Full regresija/clean checkout i status CI-ja vezani za konkretan završni checkpoint (remote nije izvršen).
- [ ] Oba člana imaju kontrolu i negativni test, mogu ponoviti provere i objasniti demo.

[Završna matrica](evidence/005-phase7-matrix.md) i
[handoff](evidence/005-phase7-handoff.md) navode stvarne komande i checkpoint-e.
Korisnik je potvrdio da ljudski deo još nije spreman. T030 i zavisni T031 ostaju
otvoreni; Week08 nije završen. Lokalni prolaz nije remote CI uspeh.

Aktuelno opaženo stanje: [EVIDENCE_W08.md](EVIDENCE_W08.md). Novi nastavni izvor
je root `weekly-assignment.md`, verzija 23.10.2026; potrebni zahtevi su preneti u
verzionisane dokumente jer nastavni paket nije garantovan u svakom checkout-u.
